module.exports = {
    jwtSecret: djasjdhuwheohOhhlklLO,
  };
  