import { hash, compare } from 'bcrypt';
import User from '../models/users.js';
import sign from 'jsonwebtoken';

export async function registerUser(req, res) {
  const { username, password } = req.body;

  if (!username || !password) {
    return res.status(400).json({ message: 'Username and password are required' });
  }

  const hashedPassword = await hash(password, 10);

  User.register(username, hashedPassword, (err) => {
    if (err) {
      console.error('Error registering user: ' + err.message);
      res.sendStatus(500);
      return;
    }
    res.json({ message: 'User registered successfully' });
  });
}

export function loginUser(req, res) {
  const { username, password } = req.body;

  if (!username || !password) {
    return res.status(400).json({ message: 'Username and password are required' });
  }

  User.findByUsername(username, async (err, results) => {
    if (err) {
      console.error('Error querying user: ' + err.message);
      res.sendStatus(500);
      return;
    }

    if (results.length === 0) {
      res.status(401).json({ message: 'Authentication failed' });
      return;
    }

    const user = results[0];

    const match = await compare(password, user.password);
    if (!match) {
      res.status(401).json({ message: 'Authentication failed' });
      return;
    }

    const token = sign({ userId: user.id }, 'your_secret_key', { expiresIn: '1h' });

    res.json({ token });
  });
}
