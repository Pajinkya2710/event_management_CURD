import Event from '../models/events.js';

export function createEvent(req, res) {
  const { name, description, creatorId } = req.body;

  if (!name || !creatorId) {
    return res.status(400).json({ message: 'Name and creatorId are required' });
  }

  Event.create(name, description, creatorId, (err) => {
    if (err) {
      console.error('Error creating event: ' + err.message);
      res.sendStatus(500);
      return;
    }
    res.json({ message: 'Event created successfully' });
  });
}

export function inviteToEvent(req, res) {
  const { eventId, userId } = req.body;

  if (!eventId || !userId) {
    return res.status(400).json({ message: 'eventId and userId are required' });
  }

  Event.invite(eventId, userId, (err) => {
    if (err) {
      console.error('Error inviting user to event: ' + err.message);
      res.sendStatus(500);
      return;
    }
    res.json({ message: 'User invited to the event' });
  });
}

export function listInvitedUsers(req, res) {
  const eventId = req.params.eventId;

  if (!eventId) {
    return res.status(400).json({ message: 'eventId is required' });
  }

  Event.listInvitedUsers(eventId, (err, results) => {
    if (err) {
      console.error('Error listing invited users: ' + err.message);
      res.sendStatus(500);
      return;
    }
    const invitedUsers = results.map((row) => row.username);
    res.json(invitedUsers);
  });
}

export function getEvent(req, res) {
  const eventId = req.params.eventId;

  if (!eventId) {
    return res.status(400).json({ message: 'eventId is required' });
  }

  Event.getEvent(eventId, (err, results) => {
    if (err) {
      console.error('Error getting event details: ' + err.message);
      res.sendStatus(500);
      return;
    }
    const event = results[0];
    if (!event) {
      return res.status(404).json({ message: 'Event not found' });
    }
    res.json(event);
  });
}

export function updateEvent(req, res) {
  const { name, description } = req.body;
  const eventId = req.params.eventId;

  if (!eventId) {
    return res.status(400).json({ message: 'eventId is required' });
  }

  Event.updateEvent(eventId, name, description, (err) => {
    if (err) {
      console.error('Error updating event: ' + err.message);
      res.sendStatus(500);
      return;
    }
    res.json({ message: 'Event updated successfully' });
  });
}
