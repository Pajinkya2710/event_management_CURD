import { Router } from 'express';
const router = Router();
import {registerUser, loginUser } from '../controllers/authControllers.js';

// Register a new user
router.post('/register', registerUser);

// Login a user
router.post('/login', loginUser);

export default router;
