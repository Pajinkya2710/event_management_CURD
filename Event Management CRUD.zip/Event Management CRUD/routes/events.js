// const express = require('express');
// const router = express.Router();
// const eventController = require('../controllers/eventController');
// const authMiddleware = require('../utils/authMiddleware');

// // Create an event (requires authentication)
// router.post('/create', authMiddleware, eventController.createEvent);

// // Invite users to an event (requires authentication and permission check)
// router.post('/:eventId/invite', authMiddleware, eventController.inviteUsers);

// module.exports = router;
import { Router } from 'express';
import { createEvent, inviteToEvent, listInvitedUsers, getEvent, updateEvent } from '../controllers/eventController.js';

const router = Router();

router.post('/create', createEvent);
router.post('/invite', inviteToEvent);
router.get('/list/:eventId/invited', listInvitedUsers);
router.get('/details/:eventId', getEvent);
router.put('/update/:eventId', updateEvent);

export default router;
