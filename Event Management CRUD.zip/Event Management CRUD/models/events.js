// import db from "./db";
import db from './db.js';

class Event {
  static create(name, description, creatorId, callback) {
    db.query(
      'INSERT INTO events (name, description, creatorId) VALUES (?, ?, ?)',
      [name, description, creatorId],
      callback
    );
  }

  static invite(eventId, userId, callback) {
    db.query('INSERT INTO event_invitations (eventId, userId) VALUES (?, ?)', [eventId, userId], callback);
  }

  static listInvitedUsers(eventId, callback) {
    db.db.query(
      'SELECT u.username FROM event_invitations ei JOIN users u ON ei.userId = u.id WHERE ei.eventId = ?',
      [eventId],
      callback
    );
  }

  static getEvent(eventId, callback) {
    db.query('SELECT * FROM events WHERE id = ?', [eventId], callback);
  }

  static updateEvent(eventId, name, description, callback) {
    db.query('UPDATE events SET name = ?, description = ? WHERE id = ?', [name, description, eventId], callback);
  }
}

export default Event;
