import db from './db.js';

class User {
  static register(username, password, callback) {
    db.query('INSERT INTO users (username, password) VALUES (?, ?)', [username, password], callback);
  }

  static findByUsername(username, callback) {
    db.query('SELECT * FROM users WHERE username = ?', [username], callback);
  }
}

export default User;
