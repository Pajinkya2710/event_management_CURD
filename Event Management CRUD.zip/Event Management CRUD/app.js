import express from 'express';
// import { json } from 'body-parser';
import authRoutes from './routes/auth.js'
import eventRoutes from './routes/events.js'
import pkg from 'body-parser';
const { json } = pkg;

const app = express();

// Middleware
app.use(json())

// Routes
app.use('/auth', authRoutes);
app.use('/events', eventRoutes);

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log(`Server is running on port ${PORT}`);
});
